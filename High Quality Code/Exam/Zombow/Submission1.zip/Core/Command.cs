﻿using Zombow.Core.Contracts;

namespace Zombow.Core
{
    public class Command : ICommand
    {
        public string Execute()
        {
            throw new System.NotImplementedException();
        }
    }
}