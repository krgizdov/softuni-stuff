﻿namespace Zombow.Core.Contracts
{
    public interface ICommand
    {
        string Execute();
    }
}