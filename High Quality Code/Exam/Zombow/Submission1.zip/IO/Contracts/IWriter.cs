﻿namespace Zombow.IO.Contracts
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}