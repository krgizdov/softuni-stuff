﻿namespace Zombow.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}